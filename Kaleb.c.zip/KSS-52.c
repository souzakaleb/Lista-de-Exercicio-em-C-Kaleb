#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
int main(){

printf("\n********************************************************************************************************\n");	
printf("\n*Aluno: Kaleb de Souza Santos - RA 0022226                                                          *\n");	
printf(" Programa KSS-52 - SOMA ATE MULTIPLO DE 10              \n"
       "O programa soma n�meros digitados pelo usu�rio.\n"
       "Ele para quando for digitado um n�mero m�ltiplo de 10.\n"
       "Ao final, exibe a soma total.\n\n");                                                                             
printf("\n********************************************************************************************************\n");


    int num, soma = 0;
    
    printf("Digite numeros (multiplo de 10 para parar):\n");
    
    do {
        scanf("%d", &num);
        if (num % 10 != 0) {
            soma += num;
        }
    } while (num % 10 != 0);
    
    printf("Soma total dos valores: %d\n", soma);
}
