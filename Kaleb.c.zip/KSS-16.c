#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
int main(){

printf("\n********************************************************************************************************\n");	
printf("\n*Aluno: Kaleb de Souza Santos - RA 0022226                                                          *\n");	
printf(" Programa KSS-16 - MULTIPLO DE 3 E/OU 5           \n"
       "Uma lanchonete criou uma promocao especial.\n"
       "Se o numero do pedido for multiplo de 3,\n"
       "o cliente ganha um refrigerante.\n"
       "Se for multiplo de 5, ganha uma sobremesa.\n"
       "Se for multiplo dos dois, ganha os dois brindes.\n"
       "O programa deve verificar o numero do pedido\n"
       "e informar qual premio o cliente ganhou.                                                                            *\n");                                                                                    
printf("\n********************************************************************************************************\n");




int pedido;

    printf("Digite o numero do pedido: ");
    scanf("%d", &pedido);

    if (pedido % 3 == 0 && pedido % 5 == 0) {
        printf("Voce ganhou um refrigerante e uma sobremesa!");
    }
    else if (pedido % 3 == 0) {
        printf("Voce ganhou um refrigerante!");
    }
    else if (pedido % 5 == 0) {
        printf("Voce ganhou uma sobremesa!");
    }
    else {
        printf("Voce nao ganhou nenhum brinde.");
    }
}
