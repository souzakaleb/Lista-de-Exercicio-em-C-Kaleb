#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
int main(){

printf("\n********************************************************************************************************\n");	
printf("\n*Aluno: Kaleb de Souza Santos - RA 0022226                                                          *\n");	
printf(" Programa KSS-21 - ANO BISSEXTO           \n"
       "Um aplicativo financeiro registra lucros e prejuizos.\n"
       "Valores positivos representam lucro e valores negativos\n"
       "representam prejuizo.\n\n"
       "O programa deve receber um numero e informar se ele e\n"
       "positivo, negativo ou zero.\n");                                                                                    
printf("\n********************************************************************************************************\n");

float numero;

    printf("Digite um numero: ");
    scanf("%f", &numero);

    if (numero > 0) {
        printf("O numero e positivo.\n");
    } else if (numero < 0) {
        printf("O numero e negativo.\n");
    } else {
        printf("O numero e zero.\n");
    }
}
