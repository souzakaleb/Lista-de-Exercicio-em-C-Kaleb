#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
int main(){

printf("\n********************************************************************************************************\n");	
printf("\n*Aluno: Kaleb de Souza Santos - RA 0022226                                                          *\n");	
printf(" Programa KSS-44 - CONTAR DIGITOS DE UM NUMERO               \n"
       "Um sistema bancario deseja identificar quantos\n"
       "digitos possui um numero informado.\n"
       "O programa deve receber um numero positivo e\n"
       "mostrar quantos digitos ele possui.\n\n");                                                                               
printf("\n********************************************************************************************************\n");
    int num, digitos = 0;

    printf("Digite um numero positivo: ");
    scanf("%d", &num);

    if (num == 0) {
        digitos = 1;
    } else {
        while (num > 0) {
            digitos++;
            num = num / 10;
        }
    }

    printf("Quantidade de digitos: %d\n", digitos);
}
