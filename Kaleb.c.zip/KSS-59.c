#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
int main(){

printf("\n********************************************************************************************************\n");	
printf("\n*Aluno: Kaleb de Souza Santos - RA 0022226                                                          *\n");	
printf(" Programa KSS-59 - ASSISTENTE DE DIRE��O (GPS)              \n"
       "Um rob� l� letras para decidir a dire��o:\n"
       "N: Seguir para o Norte.\n"
       "S: Seguir para o Sul.\n"
       "L: Virar � Leste (Direita).\n"
       "O: Virar � Oeste (Esquerda).\n"
       "Qualquer outra letra: Comando inv�lido! Pare o rob�.\n\n");                                                                              
printf("\n********************************************************************************************************\n");

char direcao;
    
    printf("Digite a letra da direcao (N, S, L, O): ");
    scanf(" %c", &direcao);
    
    switch (direcao) {
        case 'N':
        case 'n':
            printf("Seguir para o Norte.\n");
            break;
        case 'S':
        case 's':
            printf("Seguir para o Sul.\n");
            break;
        case 'L':
        case 'l':
            printf("Virar � Leste (Direita).\n");
            break;
        case 'O':
        case 'o':
            printf("Virar � Oeste (Esquerda).\n");
            break;
        default:
            printf("Comando inv�lido! Pare o rob�.\n");
    }
}
