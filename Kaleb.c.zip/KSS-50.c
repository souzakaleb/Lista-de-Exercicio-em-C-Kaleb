#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
int main(){

printf("\n********************************************************************************************************\n");	
printf("\n*Aluno: Kaleb de Souza Santos - RA 0022226                                                          *\n");	
printf(" Programa KSS-50 - NUMERO POSITIVO OBRIGATORIO               \n"
       "Um sistema banc�rio aceita apenas valores positivos.\n"
       "O programa solicita n�meros at� que o usu�rio digite um valor maior que zero.\n\n");                                                                              
printf("\n********************************************************************************************************\n");

float num;
    
    do {
        printf("Digite um numero positivo: ");
        scanf("%f", &num);
        
        if (num <= 0) {
            printf("Valor invalido! O numero deve ser positivo.\n");
        }
    } while (num <= 0);
    
    printf("Numero valido recebido: %.2f\n", num);
}
