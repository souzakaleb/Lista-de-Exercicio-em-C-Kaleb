#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
int main(){

printf("\n********************************************************************************************************\n");	
printf("\n*Aluno: Kaleb de Souza Santos - RA 0022226                                                          *\n");	
printf(" Programa KSS-24 - PODE VOTAR?           \n"
       "Um sistema de cadastro eleitoral precisa verificar se\n"
       "uma pessoa ja possui idade para votar.\n"
       "O usuario informa sua idade, e o programa deve dizer\n"
       "se ele pode ou nao votar.\n\n");                                                                                  
printf("\n********************************************************************************************************\n");


    int idade;

    printf("Digite sua idade: ");
    scanf("%d", &idade);

    if (idade >= 16) {
        printf("Voce pode votar.\n");
    } else {
        printf("Voce nao pode votar.\n");
    }
}
