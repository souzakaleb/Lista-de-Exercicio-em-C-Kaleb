#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
int main(){

printf("\n********************************************************************************************************\n");	
printf("\n*Aluno: Kaleb de Souza Santos - RA 0022226                                                          *\n");	
printf(" Programa KSS-49 - SENHA ATE ACERTAR               \n"
       "Um sistema solicita a senha repetidamente at� o usu�rio digitar 1111.\n"
       "Quando acertar, exibe 'Acesso liberado!'.\n\n");                                                                              
printf("\n********************************************************************************************************\n");

int senha;

    do {
        printf("Digite a senha: ");
        scanf("%d", &senha);

        if (senha != 1111) {
            printf("Senha incorreta!\n");
        }

    } while (senha != 1111);

    printf("Acesso liberado!\n");
}
